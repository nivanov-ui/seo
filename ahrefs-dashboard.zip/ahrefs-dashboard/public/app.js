/* ===========================================================================
   Ahrefs Monitor — frontend
   Talks only to /api/* on this origin. No API key in the browser.
   =========================================================================== */

// ---------- tiny helpers ----------
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );

function fmtInt(n) {
  if (n == null || isNaN(n)) return "—";
  return Math.round(n).toLocaleString("en-US");
}
function fmtCompact(n) {
  if (n == null || isNaN(n)) return "—";
  const a = Math.abs(n);
  if (a >= 1e6) return (n / 1e6).toFixed(a >= 1e7 ? 0 : 1) + "M";
  if (a >= 1e3) return (n / 1e3).toFixed(a >= 1e4 ? 0 : 1) + "K";
  return String(Math.round(n));
}
function fmtDate(s) {
  if (!s) return "—";
  return String(s).slice(0, 10);
}
function delta(n, { good = "up", compact = true } = {}) {
  if (n == null || n === 0) return `<span class="dim">0</span>`;
  const cls = (n > 0) === (good === "up") ? "up" : "down";
  const arrow = n > 0 ? "▲" : "▼";
  const v = compact ? fmtCompact(Math.abs(n)) : fmtInt(Math.abs(n));
  return `<span class="${cls}">${arrow} ${v}</span>`;
}
function posBadge(p) {
  if (p == null) return `<span class="pos none">—</span>`;
  let c = "rest";
  if (p <= 3) c = "top3";
  else if (p <= 10) c = "top10";
  else if (p <= 50) c = "top50";
  return `<span class="pos ${c}">#${p}</span>`;
}
function host(url) {
  try { return new URL(url).hostname.replace(/^www\./, ""); } catch { return url; }
}
function linkCell(url, label, cls = "truncate") {
  if (!url) return `<span class="dim">—</span>`;
  return `<a class="${cls}" href="${esc(url)}" target="_blank" rel="noopener" title="${esc(url)}">${esc(label ?? url)}</a>`;
}

// ---------- cached fetch ----------
const cache = {};
async function api(path, fresh) {
  if (!fresh && cache[path]) return cache[path];
  const url = path + (fresh ? (path.includes("?") ? "&" : "?") + "fresh=1" : "");
  const r = await fetch(url);
  let j;
  try { j = await r.json(); } catch { throw new Error("Bad JSON from " + path); }
  if (!r.ok) throw new Error(j.error || `HTTP ${r.status}`);
  cache[path] = j;
  return j;
}

function loadingHTML(msg = "Loading from Ahrefs…") {
  return `<div class="loading"><span class="spinner"></span>${esc(msg)}</div>`;
}
function errHTML(e) {
  return `<div class="err">⚠ ${esc(e.message || e)}</div>`;
}
function emptyHTML(msg = "No data.") {
  return `<div class="empty">${esc(msg)}</div>`;
}
function panel(title, meta, inner, flush) {
  return `<div class="panel"><div class="ph"><h3>${esc(title)}</h3>${
    meta ? `<span class="meta">${esc(meta)}</span>` : ""
  }</div><div class="pb${flush ? " flush" : ""}">${inner}</div></div>`;
}

// ---------- charts ----------
Chart.defaults.color = "#7b8499";
Chart.defaults.font.family = "IBM Plex Mono, monospace";
Chart.defaults.font.size = 10.5;
const charts = {};
const COLORS = { main: "#34d3b7", comp: "#8a7cff" };

function lineChart(canvasId, series, { compact = true } = {}) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  if (charts[canvasId]) charts[canvasId].destroy();

  // Union of dates across series, sorted.
  const dateSet = new Set();
  series.forEach((s) => (s.data || []).forEach((d) => dateSet.add(d.date)));
  const labels = [...dateSet].sort();
  const map = (arr) => {
    const m = Object.fromEntries((arr || []).map((d) => [d.date, d.value ?? d.org_traffic]));
    return labels.map((l) => (l in m ? m[l] : null));
  };

  charts[canvasId] = new Chart(ctx, {
    type: "line",
    data: {
      labels: labels.map((l) => l.slice(0, 7)),
      datasets: series.map((s) => ({
        label: s.target,
        data: map(s.data),
        borderColor: s.isMain ? COLORS.main : COLORS.comp,
        backgroundColor: s.isMain ? "rgba(52,211,183,0.12)" : "transparent",
        borderWidth: 2,
        fill: !!s.isMain,
        tension: 0.3,
        pointRadius: 0,
        pointHoverRadius: 4,
        spanGaps: true,
      })),
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: "index", intersect: false },
      plugins: {
        legend: { labels: { boxWidth: 10, boxHeight: 10, usePointStyle: true, color: "#aeb6c8" } },
        tooltip: {
          backgroundColor: "#1b1f2a", borderColor: "#262b38", borderWidth: 1,
          titleColor: "#e6e9f0", bodyColor: "#aeb6c8",
          callbacks: { label: (c) => ` ${c.dataset.label}: ${fmtInt(c.parsed.y)}` },
        },
      },
      scales: {
        x: { grid: { color: "#1a1e29" }, ticks: { maxRotation: 0, autoSkipPadding: 16 } },
        y: { grid: { color: "#1a1e29" }, ticks: { callback: (v) => (compact ? fmtCompact(v) : v) }, beginAtZero: false },
      },
    },
  });
}

function sparkline(canvasId, points, color = COLORS.main) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  if (charts[canvasId]) charts[canvasId].destroy();
  charts[canvasId] = new Chart(ctx, {
    type: "line",
    data: {
      labels: points.map((p) => p.date),
      datasets: [{ data: points.map((p) => p.health_score), borderColor: color, backgroundColor: "rgba(52,211,183,0.12)", fill: true, borderWidth: 2, tension: 0.35, pointRadius: 0, pointHoverRadius: 4 }],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, tooltip: { backgroundColor: "#1b1f2a", callbacks: { title: (c) => fmtDate(c[0].label), label: (c) => ` health ${c.parsed.y}` } } },
      scales: { x: { display: false }, y: { display: true, suggestedMin: 0, suggestedMax: 100, grid: { color: "#1a1e29" } } },
    },
  });
}

// =====================================================================
// RENDERERS
// =====================================================================

// ---- Overview ----
async function renderOverview(view, fresh) {
  view.innerHTML = `
    <div class="section-head"><h2>Overview</h2><span class="hint">Headline health for <b>${esc(TARGET)}</b> and the competitive set.</span></div>
    <div class="grid cols-5" id="kpis">
      ${["Health score", "New backlinks 30d", "Lost backlinks 30d", "Decaying pages", "Net keyword change"]
        .map((l, i) => `<div class="panel"><div class="kpi"><span class="label">${l}</span><span class="val" id="kpi${i}">…</span><span class="delta" id="kpid${i}"></span></div></div>`)
        .join("")}
    </div>
    <div style="height:16px"></div>
    <div class="panel" id="ovScore"><div class="ph"><h3>Competitor scoreboard</h3></div><div class="pb flush" id="ovScoreBody">${loadingHTML()}</div></div>
  `;

  // KPI cards (parallel, each fills independently)
  api("/api/audit", fresh).then((d) => {
    $("#kpi0").textContent = d.project.health_score ?? "—";
    $("#kpid0").innerHTML = `<span class="dim">${fmtInt(d.project.urls_with_errors)} URLs w/ errors</span>`;
    setAuditBadge(d.errors.reduce((a, e) => a + (e.crawled || 0), 0), d.errors.length);
  }).catch((e) => ($("#kpi0").innerHTML = `<span class="down" style="font-size:13px">err</span>`));

  api("/api/backlinks-new", fresh).then((d) => {
    $("#kpi1").textContent = fmtInt(d.count);
  }).catch(() => ($("#kpi1").textContent = "err"));

  api("/api/backlinks-lost", fresh).then((d) => {
    $("#kpi2").textContent = fmtInt(d.count);
    $("#kpid2").innerHTML = `<span class="dim">referring domains</span>`;
  }).catch(() => ($("#kpi2").textContent = "err"));

  api("/api/decay", fresh).then((d) => {
    $("#kpi3").textContent = fmtInt(d.losers.length);
    $("#kpid3").innerHTML = `<span class="dim">in ${esc(host(d.target) || d.target)}</span>`;
  }).catch(() => ($("#kpi3").textContent = "err"));

  api("/api/keywords-movement", fresh).then((d) => {
    const net = d.counts.new - d.counts.lost;
    $("#kpi4").textContent = (net >= 0 ? "+" : "") + fmtInt(net);
    $("#kpid4").innerHTML = `<span class="up">+${d.counts.new} new</span> · <span class="down">−${d.counts.lost} lost</span>`;
  }).catch(() => ($("#kpi4").textContent = "err"));

  // Scoreboard
  try {
    const d = await api("/api/competitors", fresh);
    $("#ovScoreBody").innerHTML = scoreboardTable(d.rows);
  } catch (e) {
    $("#ovScoreBody").innerHTML = errHTML(e);
  }
}

function scoreboardTable(rows) {
  if (!rows || !rows.length) return emptyHTML();
  const head = `<thead><tr>
    <th>Domain</th><th class="num">DR</th><th class="num">Org. traffic</th>
    <th class="num">Keywords</th><th class="num">Top-3</th><th class="num">Ref. domains</th><th class="num">Backlinks</th>
  </tr></thead>`;
  const body = rows.map((r) => {
    if (r.error) return `<tr class="${r.isMain ? "row-main" : ""}"><td class="mono">${esc(r.target)}</td><td colspan="6" class="err" style="text-align:left">${esc(r.error)}</td></tr>`;
    return `<tr class="${r.isMain ? "row-main" : ""}">
      <td class="mono">${esc(r.target)}</td>
      <td class="num">${r.dr != null ? r.dr.toFixed(0) : "—"}</td>
      <td class="num">${fmtCompact(r.org_traffic)}</td>
      <td class="num">${fmtCompact(r.org_keywords)}</td>
      <td class="num">${fmtCompact(r.org_keywords_top3)}</td>
      <td class="num">${fmtCompact(r.refdomains)}</td>
      <td class="num">${fmtCompact(r.backlinks)}</td>
    </tr>`;
  }).join("");
  return `<table>${head}<tbody>${body}</tbody></table>`;
}

// ---- Site Audit ----
async function renderAudit(view, fresh) {
  view.innerHTML = `<div class="section-head"><h2>Site Audit</h2><span class="hint">Project <b id="auP"></b> · last crawl <b id="auD"></b></span></div><div id="auBody">${loadingHTML()}</div>`;
  let d;
  try { d = await api("/api/audit", fresh); }
  catch (e) { $("#auBody").innerHTML = errHTML(e); return; }

  $("#auP").textContent = d.project.name || d.project.id;
  $("#auD").textContent = fmtDate(d.project.crawl_date);

  const hs = d.project.health_score ?? 0;
  const headTop = `<div class="grid cols-3">
    ${panel("Health score", null, `<div class="health">
        <div class="ring" style="--p:${hs}"><span>${hs}</span></div>
        <div>
          <div class="chip"><i style="background:var(--down)"></i> ${fmtInt(d.project.urls_with_errors)} URLs with errors</div>
          <div class="chip"><i style="background:var(--amber)"></i> ${fmtInt(d.project.urls_with_warnings)} URLs with warnings</div>
          <div class="chip"><i style="background:var(--muted)"></i> ${fmtInt(d.project.total)} crawled</div>
        </div>
      </div>`)}
    <div class="panel" style="grid-column: span 2"><div class="ph"><h3>Health score trend</h3><span class="meta">${d.trend.length} crawls</span></div><div class="pb" style="height:150px"><canvas id="healthSpark"></canvas></div></div>
  </div>`;

  const errTable = d.errors.length
    ? `<table id="errTable"><thead><tr><th>Error</th><th>Category</th><th class="num">URLs</th></tr></thead><tbody>
        ${d.errors.map((e) => `
          <tr class="issue-row" data-id="${esc(e.issue_id)}">
            <td><span class="chev">▸</span> ${esc(e.name)}</td>
            <td class="dim">${esc(e.category)}</td>
            <td class="num"><span class="tag err">${fmtInt(e.crawled)}</span></td>
          </tr>`).join("")}
      </tbody></table>`
    : emptyHTML("No errors 🎉");

  const warnList = d.warnings.length
    ? `<div class="wlist">${d.warnings.map((w) => `<div class="w"><span class="n">${esc(w.name)}</span><span class="c">${fmtInt(w.crawled)}</span></div>`).join("")}</div>`
    : emptyHTML("No warnings.");

  $("#auBody").innerHTML = `
    ${headTop}
    <div style="height:16px"></div>
    ${panel("Errors", "click a row to see affected pages", errTable, true)}
    <div style="height:16px"></div>
    ${panel("Warnings", `${d.warnings.length} types`, warnList)}
    ${d.notices.length ? `<div style="height:16px"></div>` + panel("Notices", `${d.notices.length} types`, `<div class="wlist">${d.notices.map((w) => `<div class="w"><span class="n">${esc(w.name)}</span><span class="c dim">${fmtInt(w.crawled)}</span></div>`).join("")}</div>`) : ""}
  `;

  sparkline("healthSpark", d.trend);

  // Drill-in
  $$("#errTable .issue-row").forEach((row) => {
    row.addEventListener("click", () => toggleIssue(row));
  });
}

async function toggleIssue(row) {
  const id = row.dataset.id;
  const existing = row.nextElementSibling;
  if (existing && existing.classList.contains("issue-pages")) {
    existing.remove();
    row.classList.remove("open");
    return;
  }
  row.classList.add("open");
  const tr = document.createElement("tr");
  tr.className = "issue-pages";
  tr.innerHTML = `<td colspan="3"><div class="inner">${loadingHTML("Loading affected pages…")}</div></td>`;
  row.after(tr);
  try {
    const d = await api(`/api/audit-pages?issue_id=${encodeURIComponent(id)}`, false);
    const inner = tr.querySelector(".inner");
    if (!d.pages.length) { inner.innerHTML = emptyHTML("No pages returned."); return; }
    inner.innerHTML = `<ul style="margin:0;padding:0">${d.pages.map((p) => `
      <li><span class="code">${p.http_code ?? ""}</span>
      <a href="${esc(p.url)}" target="_blank" rel="noopener" class="truncate">${esc(p.url)}</a></li>`).join("")}</ul>
      <div class="muted-note">${d.count} pages${d.count >= 200 ? " (capped)" : ""}</div>`;
  } catch (e) {
    tr.querySelector(".inner").innerHTML = errHTML(e);
  }
}

// ---- Traffic & authority ----
async function renderTraffic(view, fresh) {
  view.innerHTML = `
    <div class="section-head"><h2>Traffic &amp; authority</h2><span class="hint"><b>${esc(TARGET)}</b> vs <b>${esc(COMPETITOR)}</b> — Ahrefs estimates for both.</span></div>
    ${panel("Organic traffic", "monthly, est.", `<div style="height:300px"><canvas id="trafficChart"></canvas></div>`)}
    <div style="height:16px"></div>
    <div class="grid cols-2">
      ${panel("Domain Rating", null, `<div style="height:240px"><canvas id="drChart"></canvas></div>`)}
      ${panel("Referring domains", null, `<div style="height:240px"><canvas id="rdChart"></canvas></div>`)}
    </div>`;
  try {
    const [t, a] = await Promise.all([api("/api/traffic", fresh), api("/api/authority", fresh)]);
    lineChart("trafficChart", t.series.map((s) => ({ target: s.target, isMain: s.isMain, data: s.data })));
    lineChart("drChart", a.domainRating, { compact: false });
    lineChart("rdChart", a.refdomains);
  } catch (e) {
    view.querySelector(".pb").innerHTML = errHTML(e);
  }
}

// ---- Keywords ----
async function renderKeywords(view, fresh) {
  view.innerHTML = `
    <div class="section-head"><h2>Keywords</h2><span class="hint">Tracked list + organic movement over the last 30 days.</span></div>
    ${panel("Tracked keywords", null, `<div id="trBody">${loadingHTML()}</div>`, true)}
    <div style="height:16px"></div>
    <div class="panel"><div class="ph"><h3>Position movement</h3><span class="meta" id="mvWindow"></span></div>
      <div class="pb"><div class="subtabs" id="mvTabs"></div><div id="mvBody">${loadingHTML()}</div></div></div>`;

  api("/api/keywords-tracked", fresh).then((d) => {
    if (!d.tracked.length) { $("#trBody").innerHTML = emptyHTML(); return; }
    $("#trBody").innerHTML = `<table><thead><tr><th>Keyword</th><th class="num">Position</th><th class="num">Volume</th><th class="num">KD</th><th class="num">Traffic</th><th>Ranking URL</th></tr></thead><tbody>
      ${d.tracked.map((k) => `<tr>
        <td>${esc(k.keyword)}</td>
        <td class="num">${k.notRanking ? `<span class="pos none">not&nbsp;ranking</span>` : posBadge(k.position)}</td>
        <td class="num">${fmtInt(k.volume)}</td>
        <td class="num">${k.kd ?? "—"}</td>
        <td class="num">${fmtInt(k.traffic)}</td>
        <td>${linkCell(k.url, k.url ? new URL(k.url).pathname : null, "truncate-sm")}</td>
      </tr>`).join("")}</tbody></table>`;
  }).catch((e) => ($("#trBody").innerHTML = errHTML(e)));

  api("/api/keywords-movement", fresh).then((d) => {
    $("#mvWindow").textContent = `${fmtDate(d.window.from)} → ${fmtDate(d.window.to)}`;
    const tabs = [
      ["new", "New", d.counts.new, "up"],
      ["improved", "Improved", d.improved.length, "up"],
      ["dropped", "Dropped", d.counts.dropped, "down"],
      ["lost", "Lost", d.counts.lost, "down"],
    ];
    $("#mvTabs").innerHTML = tabs.map(([k, l, n], i) => `<button data-k="${k}" class="${i === 0 ? "active" : ""}">${l} <span class="n">${n}</span></button>`).join("");
    const draw = (k) => { $("#mvBody").innerHTML = movementTable(d[k], k); };
    $$("#mvTabs button").forEach((b) => b.addEventListener("click", () => {
      $$("#mvTabs button").forEach((x) => x.classList.remove("active"));
      b.classList.add("active");
      draw(b.dataset.k);
    }));
    draw("new");
  }).catch((e) => ($("#mvBody").innerHTML = errHTML(e)));
}

function movementTable(rows, kind) {
  if (!rows || !rows.length) return emptyHTML("Nothing here for this window.");
  const showPrev = kind === "dropped" || kind === "improved";
  return `<table><thead><tr><th>Keyword</th><th class="num">Position</th>${showPrev ? `<th class="num">Was</th>` : ""}<th class="num">Volume</th><th class="num">Traffic</th><th>URL</th></tr></thead><tbody>
    ${rows.slice(0, 60).map((r) => `<tr>
      <td>${esc(r.keyword)}</td>
      <td class="num">${kind === "lost" ? `<span class="pos none">—</span>` : posBadge(r.position)}</td>
      ${showPrev ? `<td class="num dim">#${r.position_prev ?? "—"}</td>` : ""}
      <td class="num">${fmtInt(r.volume)}</td>
      <td class="num">${fmtInt(kind === "lost" ? r.traffic_prev : r.traffic)}</td>
      <td>${linkCell(r.url, r.url ? new URL(r.url).pathname : null, "truncate-sm")}</td>
    </tr>`).join("")}</tbody></table>`;
}

// ---- Backlinks ----
async function renderBacklinks(view, fresh) {
  view.innerHTML = `
    <div class="section-head"><h2>Backlinks</h2><span class="hint">New &amp; lost over 30 days, plus reclamation opportunities.</span></div>
    <div class="subtabs" id="blTabs">
      <button data-k="new" class="active">New <span class="n" id="cnew"></span></button>
      <button data-k="lost">Lost <span class="n" id="clost"></span></button>
      <button data-k="broken">Broken <span class="n" id="cbroken"></span></button>
    </div>
    <div id="blBody">${loadingHTML()}</div>`;

  const state = {};
  const draw = async (k) => {
    $("#blBody").innerHTML = loadingHTML();
    try {
      if (k === "new") {
        const d = state.new || (state.new = await api("/api/backlinks-new", fresh));
        $("#cnew").textContent = d.count;
        $("#blBody").innerHTML = backlinkTable(d.links, "new");
      } else if (k === "lost") {
        const d = state.lost || (state.lost = await api("/api/backlinks-lost", fresh));
        $("#clost").textContent = d.count;
        $("#blBody").innerHTML = backlinkTable(d.links, "lost");
      } else {
        const d = state.broken || (state.broken = await api("/api/backlinks-broken", fresh));
        $("#cbroken").textContent = d.count;
        $("#blBody").innerHTML = backlinkTable(d.links, "broken");
      }
    } catch (e) { $("#blBody").innerHTML = errHTML(e); }
  };
  $$("#blTabs button").forEach((b) => b.addEventListener("click", () => {
    $$("#blTabs button").forEach((x) => x.classList.remove("active"));
    b.classList.add("active"); draw(b.dataset.k);
  }));
  // preload counts for the other tabs quietly
  api("/api/backlinks-new", fresh).then((d) => ($("#cnew").textContent = d.count)).catch(() => {});
  api("/api/backlinks-lost", fresh).then((d) => ($("#clost").textContent = d.count)).catch(() => {});
  api("/api/backlinks-broken", fresh).then((d) => ($("#cbroken").textContent = d.count)).catch(() => {});
  draw("new");
}

function backlinkTable(links, kind) {
  if (!links || !links.length) return emptyHTML("No links in this view.");
  const dateCol = kind === "new" ? "First seen" : kind === "lost" ? "Lost" : "Target code";
  return `<div class="panel"><div class="pb flush"><table><thead><tr>
      <th class="num">DR</th><th>Referring page</th><th>Anchor</th><th>Links to</th>
      <th class="num">Ref. traffic</th><th>${dateCol}</th><th></th>
    </tr></thead><tbody>
    ${links.map((b) => `<tr>
      <td class="num">${b.dr != null ? b.dr.toFixed(0) : "—"}</td>
      <td>${linkCell(b.url_from, host(b.url_from), "truncate-sm")}<div class="dim truncate-sm" style="font-size:11px">${esc(b.title || "")}</div></td>
      <td class="truncate-sm dim">${esc(b.anchor || "—")}</td>
      <td>${linkCell(b.url_to, b.url_to ? new URL(b.url_to).pathname : null, "truncate-sm")}</td>
      <td class="num">${fmtCompact(b.referring_traffic)}</td>
      <td class="mono dim">${
        kind === "broken"
          ? `<span class="tag err">${b.target_code ?? "?"}</span>`
          : kind === "new" ? fmtDate(b.first_seen) : `${fmtDate(b.last_seen)}${b.lost_reason ? ` · ${esc(b.lost_reason)}` : ""}`
      }</td>
      <td>${b.dofollow === false ? `<span class="tag nofollow">nofollow</span>` : ""}</td>
    </tr>`).join("")}</tbody></table></div></div>`;
}

// ---- Decay radar ----
async function renderDecay(view, fresh) {
  view.innerHTML = `<div class="section-head"><h2>Decay radar</h2><span class="hint">Pages losing organic traffic in <b id="dcT"></b> — refresh candidates first.</span></div><div id="dcBody">${loadingHTML()}</div>`;
  let d;
  try { d = await api("/api/decay", fresh); } catch (e) { $("#dcBody").innerHTML = errHTML(e); return; }
  $("#dcT").textContent = host(d.target) || d.target;

  const tbl = (rows, losing) => rows.length
    ? `<div class="panel"><div class="pb flush"><table><thead><tr><th>Page</th><th class="num">Traffic now</th><th class="num">Was</th><th class="num">Δ</th><th>Top keyword</th><th class="num">Pos</th></tr></thead><tbody>
        ${rows.slice(0, 40).map((p) => `<tr>
          <td>${linkCell(p.url, new URL(p.url).pathname)}</td>
          <td class="num">${fmtInt(p.traffic)}</td>
          <td class="num dim">${fmtInt(p.traffic_prev)}</td>
          <td class="num">${delta(p.traffic_diff, { good: "up", compact: false })}</td>
          <td class="truncate-sm dim">${esc(p.top_keyword || "—")}</td>
          <td class="num">${posBadge(p.top_position)}</td>
        </tr>`).join("")}</tbody></table></div></div>`
    : emptyHTML(losing ? "No declining pages — nice." : "No gainers in window.");

  $("#dcBody").innerHTML = `
    ${panel(`Losing traffic — refresh candidates`, `${d.losers.length} pages · ${fmtDate(d.window.from)} → ${fmtDate(d.window.to)}`, tbl(d.losers, true), true)}
    <div style="height:16px"></div>
    ${panel("Gaining traffic", `${d.gainers.length} pages`, tbl(d.gainers, false), true)}`;
}

// ---- Scoreboard (full) ----
async function renderScoreboard(view, fresh) {
  view.innerHTML = `<div class="section-head"><h2>Competitors</h2><span class="hint">Authority &amp; visibility snapshot vs the competitive set.</span></div><div class="panel"><div class="pb flush" id="sbBody">${loadingHTML()}</div></div>`;
  try { const d = await api("/api/competitors", fresh); $("#sbBody").innerHTML = scoreboardTable(d.rows); }
  catch (e) { $("#sbBody").innerHTML = errHTML(e); }
}

// =====================================================================
// router + chrome
// =====================================================================
const RENDERERS = {
  overview: renderOverview, audit: renderAudit, traffic: renderTraffic,
  keywords: renderKeywords, backlinks: renderBacklinks, decay: renderDecay,
  scoreboard: renderScoreboard,
};
const TITLES = {
  overview: "Overview", audit: "Site Audit", traffic: "Traffic & authority",
  keywords: "Keywords", backlinks: "Backlinks", decay: "Decay radar", scoreboard: "Competitors",
};
let TARGET = "adapty.io", COMPETITOR = "revenuecat.com";
let current = "overview";

function setAuditBadge(urlCount, types) {
  const b = $("#navAuditBadge");
  if (!b) return;
  b.textContent = types ? `${types}` : "";
  b.classList.toggle("alert", types > 0);
}

function show(viewName, fresh = false) {
  current = viewName;
  $$("#nav button").forEach((b) => b.classList.toggle("active", b.dataset.view === viewName));
  $$(".view").forEach((v) => v.classList.toggle("active", v.id === `view-${viewName}`));
  $("#pageTitle").textContent = TITLES[viewName];
  const view = $(`#view-${viewName}`);
  RENDERERS[viewName](view, fresh);
}

async function loadUsage(fresh) {
  try {
    const u = await api("/api/usage", fresh);
    if (u.limit && u.used != null) {
      const pct = Math.min(100, (u.used / u.limit) * 100);
      $("#unitsText").textContent = `${fmtCompact(u.used)} / ${fmtCompact(u.limit)} units`;
      $("#unitsBar").style.width = pct + "%";
      if (pct > 80) $("#unitsBar").style.background = "var(--down)";
    }
    if (u.reset_date) $("#footReset").textContent = `Resets ${fmtDate(u.reset_date)}`;
  } catch { $("#unitsText").textContent = "units —"; }
}

function init() {
  // Pull target labels from the config-backed audit/traffic responses lazily;
  // defaults are fine for first paint.
  $$("#nav button").forEach((b) => b.addEventListener("click", () => show(b.dataset.view)));
  $("#refreshBtn").addEventListener("click", async () => {
    const btn = $("#refreshBtn");
    btn.disabled = true; btn.textContent = "↻ Refreshing…";
    for (const k of Object.keys(cache)) delete cache[k];
    await Promise.all([loadUsage(true)]);
    show(current, true);
    setTimeout(() => { btn.disabled = false; btn.textContent = "↻ Refresh"; }, 600);
  });
  loadUsage(false);
  show("overview");

  // Best-effort: learn real domain labels from traffic endpoint for the headings.
  api("/api/traffic").then((t) => {
    if (t.series?.[0]?.target) { TARGET = t.series[0].target; $("#brandTarget").textContent = TARGET; }
    if (t.series?.[1]?.target) COMPETITOR = t.series[1].target;
  }).catch(() => {});
}

document.addEventListener("DOMContentLoaded", init);
