import { ahrefsGet, withHandler, today, daysAgo } from "./_ahrefs.js";
import { config } from "./_config.js";

// Top pages with traffic change vs ~1 month ago. Sorted so the biggest losers
// (refresh candidates) surface first, plus the biggest gainers for context.
export default withHandler(config.cacheTtl.decay, async () => {
  const date = today();
  const dateCompared = daysAgo(config.backlinksWindowDays);

  const body = await ahrefsGet("site-explorer/top-pages", {
    target: config.decayTarget || config.mainDomain,
    mode: config.decayMode || "prefix",
    date,
    date_compared: dateCompared,
    volume_mode: "monthly",
    country: config.country || undefined,
    select:
      "url,sum_traffic,sum_traffic_prev,traffic_diff,top_keyword,top_keyword_best_position,keywords,keywords_prev",
    order_by: "traffic_diff:asc",
    limit: config.limits.decay,
  });

  const pages = (body.pages || [])
    .filter((p) => p.url)
    .map((p) => ({
      url: p.url,
      traffic: p.sum_traffic ?? 0,
      traffic_prev: p.sum_traffic_prev ?? 0,
      traffic_diff: p.traffic_diff ?? 0,
      top_keyword: p.top_keyword ?? null,
      top_position: p.top_keyword_best_position ?? null,
      keywords: p.keywords ?? null,
      keywords_prev: p.keywords_prev ?? null,
    }));

  const losers = pages.filter((p) => p.traffic_diff < 0);
  const gainers = pages
    .filter((p) => p.traffic_diff > 0)
    .sort((a, b) => b.traffic_diff - a.traffic_diff);

  return {
    window: { from: dateCompared, to: date },
    target: config.decayTarget || config.mainDomain,
    losers, // refresh candidates, biggest drop first
    gainers,
  };
});
