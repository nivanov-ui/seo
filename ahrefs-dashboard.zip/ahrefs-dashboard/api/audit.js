import { ahrefsGet, withHandler, daysAgo, settle } from "./_ahrefs.js";
import { config } from "./_config.js";

async function projectAt(projectId, date) {
  const params = { project_id: projectId };
  if (date) params.date = `${date}T23:59:59`;
  const body = await ahrefsGet("site-audit/projects", params);
  const list = body.healthscores || [];
  return list[0] || null;
}

export default withHandler(config.cacheTtl.audit, async () => {
  const projectId = config.siteAuditProjectId;

  // Current snapshot + full issue list, in parallel.
  const [current, issuesBody] = await Promise.all([
    projectAt(projectId),
    ahrefsGet("site-audit/issues", { project_id: projectId }),
  ]);

  const issues = (issuesBody.issues || []).map((i) => ({
    issue_id: i.issue_id,
    name: i.name,
    importance: i.importance, // Error | Warning | Notice
    category: i.category,
    crawled: i.crawled, // number of affected URLs
  }));

  const errors = issues
    .filter((i) => i.importance === "Error" && i.crawled > 0)
    .sort((a, b) => b.crawled - a.crawled);
  const warnings = issues
    .filter((i) => i.importance === "Warning" && i.crawled > 0)
    .sort((a, b) => b.crawled - a.crawled);
  const notices = issues
    .filter((i) => i.importance === "Notice" && i.crawled > 0)
    .sort((a, b) => b.crawled - a.crawled);

  // Health-score trend: sample past crawls.
  const trendDates = [];
  for (let i = config.healthTrendPoints - 1; i >= 0; i--) {
    trendDates.push(daysAgo(i * config.healthTrendStepDays));
  }
  const sampled = await settle(trendDates.map((d) => projectAt(projectId, d)));
  const seen = new Set();
  const trend = [];
  sampled.forEach((s) => {
    const p = s.value;
    if (!p || p.health_score == null) return;
    const key = p.date || p.health_score; // de-dupe identical crawls
    if (seen.has(p.date)) return;
    seen.add(p.date);
    trend.push({ date: (p.date || "").slice(0, 10), health_score: p.health_score });
  });

  return {
    project: {
      id: current?.project_id ?? projectId,
      name: current?.project_name ?? null,
      target_url: current?.target_url ?? config.mainDomain,
      crawl_date: current?.date ?? null,
      status: current?.status ?? null,
      health_score: current?.health_score ?? null,
      urls_with_errors: current?.urls_with_errors ?? null,
      urls_with_warnings: current?.urls_with_warnings ?? null,
      urls_with_notices: current?.urls_with_notices ?? null,
      total: current?.total ?? null,
    },
    errors,
    warnings,
    notices,
    trend,
  };
});
