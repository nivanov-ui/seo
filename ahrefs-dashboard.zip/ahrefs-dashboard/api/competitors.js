import { ahrefsGet, withHandler, today, settle } from "./_ahrefs.js";
import { config } from "./_config.js";

async function snapshot(target) {
  const date = today();
  const [metrics, dr, links] = await Promise.all([
    ahrefsGet("site-explorer/metrics", {
      target,
      mode: "subdomains",
      date,
      volume_mode: "monthly",
      country: config.country || undefined,
    }),
    ahrefsGet("site-explorer/domain-rating", { target, date }),
    ahrefsGet("site-explorer/backlinks-stats", { target, mode: "subdomains", date }),
  ]);
  const m = metrics.metrics || {};
  return {
    target,
    dr: dr.domain_rating?.domain_rating ?? null,
    org_traffic: m.org_traffic ?? null,
    org_keywords: m.org_keywords ?? null,
    org_keywords_top3: m.org_keywords_1_3 ?? null,
    refdomains: links.metrics?.live_refdomains ?? null,
    backlinks: links.metrics?.live ?? null,
  };
}

export default withHandler(config.cacheTtl.competitors, async () => {
  const targets = [config.mainDomain, ...config.competitors.filter((c) => c !== config.mainDomain)];
  const results = await settle(targets.map(snapshot));

  const rows = results.map((r, i) =>
    r.value
      ? { ...r.value, isMain: i === 0, error: null }
      : { target: targets[i], isMain: i === 0, error: r.error }
  );

  return { rows };
});
