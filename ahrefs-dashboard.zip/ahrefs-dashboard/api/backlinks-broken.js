import { ahrefsGet, withHandler } from "./_ahrefs.js";
import { config } from "./_config.js";

// Links pointing at broken target pages (your 404s etc.) — fix with a redirect
// to reclaim the link equity.
export default withHandler(config.cacheTtl.backlinks, async () => {
  const body = await ahrefsGet("site-explorer/broken-backlinks", {
    target: config.mainDomain,
    mode: "subdomains",
    aggregation: "1_per_domain",
    select:
      "url_from,url_to,http_code_target,anchor,domain_rating_source,traffic_domain,is_dofollow,title",
    order_by: "domain_rating_source:desc",
    limit: config.limits.backlinks,
  });

  const links = (body.backlinks || []).map((b) => ({
    url_from: b.url_from,
    url_to: b.url_to,
    target_code: b.http_code_target,
    anchor: b.anchor,
    dr: b.domain_rating_source,
    referring_traffic: b.traffic_domain,
    dofollow: b.is_dofollow,
    title: b.title,
  }));

  return { count: links.length, links };
});
