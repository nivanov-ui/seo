import { ahrefsGet, withHandler, monthsAgo, today, settle } from "./_ahrefs.js";
import { config } from "./_config.js";

async function trafficSeries(target) {
  const body = await ahrefsGet("site-explorer/metrics-history", {
    target,
    mode: "subdomains",
    date_from: monthsAgo(config.historyMonths),
    date_to: today(),
    history_grouping: "monthly",
    volume_mode: "monthly",
    select: "date,org_traffic",
    country: config.country || undefined,
  });
  return (body.metrics || []).map((m) => ({ date: m.date, org_traffic: m.org_traffic }));
}

export default withHandler(config.cacheTtl.traffic, async () => {
  const targets = [config.mainDomain, config.competitor];
  const results = await settle(targets.map(trafficSeries));
  return {
    series: targets.map((target, i) => ({
      target,
      isMain: i === 0,
      data: results[i].value || [],
      error: results[i].error || null,
    })),
  };
});
