import { ahrefsGet, withHandler, daysAgo } from "./_ahrefs.js";
import { config } from "./_config.js";

// Backlinks lost within the window. history=since:<date> brings lost links
// into the report; we then keep only the ones actually marked lost.
export default withHandler(config.cacheTtl.backlinks, async () => {
  const since = daysAgo(config.backlinksWindowDays);

  const body = await ahrefsGet("site-explorer/all-backlinks", {
    target: config.mainDomain,
    mode: "subdomains",
    history: `since:${since}`,
    aggregation: "1_per_domain",
    select:
      "url_from,url_to,anchor,domain_rating_source,traffic_domain,last_seen,lost_reason,is_dofollow,link_type,title",
    where: {
      and: [
        { field: "is_lost", is: ["eq", true] },
        { field: "last_seen", is: ["gte", since] },
      ],
    },
    order_by: "last_seen:desc",
    limit: config.limits.backlinks,
  });

  const links = (body.backlinks || []).map((b) => ({
    url_from: b.url_from,
    url_to: b.url_to,
    anchor: b.anchor,
    dr: b.domain_rating_source,
    referring_traffic: b.traffic_domain,
    last_seen: b.last_seen,
    lost_reason: b.lost_reason,
    dofollow: b.is_dofollow,
    type: b.link_type,
    title: b.title,
  }));

  return { since, count: links.length, links };
});
