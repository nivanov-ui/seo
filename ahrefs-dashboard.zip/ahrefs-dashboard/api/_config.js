// ---------------------------------------------------------------------------
// CONFIG — edit this file to change what the dashboard monitors.
// Nothing secret lives here (safe to commit). The API key is read separately
// from the AHREFS_API_KEY environment variable (see README).
// ---------------------------------------------------------------------------

export const config = {
  // Main site you monitor.
  mainDomain: "adapty.io",

  // Primary competitor shown next to the main site on traffic / authority charts.
  competitor: "revenuecat.com",

  // Full competitor set for the scoreboard (the main domain is added automatically).
  competitors: [
    "revenuecat.com",
    "superwall.com",
    "qonversion.io",
    "apphud.com",
  ],

  // Site Audit project ID (find it in the Ahrefs Site Audit URL:
  // https://app.ahrefs.com/site-audit/<PROJECT_ID>).
  siteAuditProjectId: 2389363,

  // Section used for the "decay radar" (top pages + traffic movement).
  // Use the blog path so refresh candidates surface first. Set to "" to scan
  // the whole site. `decayMode` controls scope: "prefix" = everything under the
  // path; "subdomains" = whole domain incl. subdomains.
  decayTarget: "adapty.io/blog/",
  decayMode: "prefix",

  // Country scope for keyword/traffic data. "" = worldwide.
  country: "",

  // Tracked keyword list — current ranking position is pulled for each of these.
  // Keywords not in adapty.io's top 100 will show as "not ranking".
  trackedKeywords: [
    "in-app subscription",
    "mobile subscription management",
    "paywall builder",
    "app monetization",
    "subscription analytics",
    "revenuecat alternative",
    "in-app purchase sdk",
    "app store server notifications",
    "subscription paywall",
    "freemium model",
  ],

  // How far back the trend charts look (months).
  historyMonths: 14,

  // "New backlinks" / "lost backlinks" look-back window (days).
  backlinksWindowDays: 30,

  // How many health-score data points to sample for the audit trend.
  healthTrendPoints: 8,
  healthTrendStepDays: 14,

  // Row caps for table endpoints (REST honours these; the MCP does not).
  limits: {
    backlinks: 100,
    decay: 60,
    keywordMovement: 100,
    auditPages: 200,
  },

  // Edge-cache TTL per endpoint, in seconds. Vercel caches the function
  // response on its CDN for this long (cuts Ahrefs API-unit spend hugely).
  // A hard refresh in the UI appends a cache-busting param to bypass it.
  cacheTtl: {
    audit: 6 * 3600,        // 6h
    auditPages: 6 * 3600,
    traffic: 24 * 3600,     // 24h — history moves slowly
    authority: 24 * 3600,
    keywordsTracked: 12 * 3600,
    keywordMovement: 12 * 3600,
    backlinks: 6 * 3600,
    decay: 24 * 3600,
    competitors: 24 * 3600,
    usage: 1800,            // 30m
  },
};

export default config;
