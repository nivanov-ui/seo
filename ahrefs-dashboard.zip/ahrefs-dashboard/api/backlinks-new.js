import { ahrefsGet, withHandler, daysAgo } from "./_ahrefs.js";
import { config } from "./_config.js";

// Backlinks first discovered in the last `backlinksWindowDays` days.
export default withHandler(config.cacheTtl.backlinks, async () => {
  const since = daysAgo(config.backlinksWindowDays);

  const body = await ahrefsGet("site-explorer/all-backlinks", {
    target: config.mainDomain,
    mode: "subdomains",
    history: "live",
    aggregation: "1_per_domain",
    select:
      "url_from,url_to,anchor,domain_rating_source,traffic_domain,first_seen_link,is_dofollow,link_type,title",
    where: { field: "first_seen_link", is: ["gte", since] },
    order_by: "first_seen_link:desc",
    limit: config.limits.backlinks,
  });

  const links = (body.backlinks || []).map((b) => ({
    url_from: b.url_from,
    url_to: b.url_to,
    anchor: b.anchor,
    dr: b.domain_rating_source,
    referring_traffic: b.traffic_domain,
    first_seen: b.first_seen_link,
    dofollow: b.is_dofollow,
    type: b.link_type,
    title: b.title,
  }));

  return { since, count: links.length, links };
});
