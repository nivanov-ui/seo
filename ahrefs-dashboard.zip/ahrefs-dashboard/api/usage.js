import { ahrefsGet, withHandler } from "./_ahrefs.js";
import { config } from "./_config.js";

// Free Ahrefs endpoint — shows how many API units are left this cycle.
export default withHandler(config.cacheTtl.usage, async () => {
  const body = await ahrefsGet("subscription-info/limits-and-usage", {});
  const u = body.limits_and_usage || {};
  const limit = u.units_limit_workspace ?? null;
  const used = u.units_usage_workspace ?? null;
  return {
    subscription: u.subscription ?? null,
    reset_date: u.usage_reset_date ?? null,
    limit,
    used,
    remaining: limit != null && used != null ? limit - used : null,
  };
});
