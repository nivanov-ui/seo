import { ahrefsGet, withHandler, today, whereKeywordIn } from "./_ahrefs.js";
import { config } from "./_config.js";

// Current rank of adapty.io for each keyword in config.trackedKeywords.
// One API call: organic-keywords filtered to the list. Keywords outside the
// top 100 simply won't come back from Ahrefs -> shown as "not ranking".
export default withHandler(config.cacheTtl.keywordsTracked, async () => {
  const keywords = config.trackedKeywords || [];
  if (!keywords.length) return { tracked: [] };

  const body = await ahrefsGet("site-explorer/organic-keywords", {
    target: config.mainDomain,
    mode: "subdomains",
    date: today(),
    country: config.country || undefined,
    volume_mode: "monthly",
    select:
      "keyword,best_position,best_position_url,volume,sum_traffic,keyword_difficulty",
    where: whereKeywordIn(keywords),
    order_by: "best_position:asc",
    limit: Math.max(keywords.length * 2, 50),
  });

  const found = new Map();
  for (const k of body.keywords || []) {
    // Keep the best (lowest) position per keyword.
    const existing = found.get(k.keyword);
    if (!existing || (k.best_position ?? 999) < (existing.best_position ?? 999)) {
      found.set(k.keyword, {
        keyword: k.keyword,
        position: k.best_position ?? null,
        url: k.best_position_url ?? null,
        volume: k.volume ?? null,
        traffic: k.sum_traffic ?? null,
        kd: k.keyword_difficulty ?? null,
      });
    }
  }

  // Preserve the configured order; fill in non-ranking keywords explicitly.
  const tracked = keywords.map(
    (kw) =>
      found.get(kw) || {
        keyword: kw,
        position: null,
        url: null,
        volume: null,
        traffic: null,
        kd: null,
        notRanking: true,
      }
  );

  return { tracked };
});
