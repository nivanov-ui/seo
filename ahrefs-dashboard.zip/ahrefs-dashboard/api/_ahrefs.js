// ---------------------------------------------------------------------------
// Shared Ahrefs API v3 client + helpers.
// The API key NEVER reaches the browser: it lives only in process.env here,
// on the server side. The frontend only ever talks to /api/* on this origin.
// ---------------------------------------------------------------------------

const API_BASE = "https://api.ahrefs.com/v3";

export function getToken() {
  const token = process.env.AHREFS_API_KEY;
  if (!token) {
    throw new ApiError(
      500,
      "AHREFS_API_KEY is not set. Add it in Vercel → Settings → Environment Variables."
    );
  }
  return token;
}

export class ApiError extends Error {
  constructor(status, message, detail) {
    super(message);
    this.status = status;
    this.detail = detail;
  }
}

// Build a query string, dropping null/undefined values. Objects/arrays are
// JSON-stringified (Ahrefs expects `where`/`select` style params as strings).
function buildQuery(params = {}) {
  const usp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v === null || v === undefined || v === "") continue;
    if (typeof v === "object") usp.append(k, JSON.stringify(v));
    else usp.append(k, String(v));
  }
  return usp.toString();
}

// Core GET request to the Ahrefs API. `path` is the part after /v3/,
// e.g. "site-explorer/metrics-history".
export async function ahrefsGet(path, params = {}) {
  const token = getToken();
  const qs = buildQuery({ output: "json", ...params });
  const url = `${API_BASE}/${path}${qs ? `?${qs}` : ""}`;

  let resp;
  try {
    resp = await fetch(url, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
    });
  } catch (err) {
    throw new ApiError(502, `Network error reaching Ahrefs: ${err.message}`);
  }

  const text = await resp.text();
  let body;
  try {
    body = text ? JSON.parse(text) : {};
  } catch {
    body = { raw: text };
  }

  if (!resp.ok) {
    // Surface Ahrefs' own error message so misconfiguration is easy to debug.
    const msg =
      body?.error || body?.message || body?.raw || `Ahrefs returned ${resp.status}`;
    throw new ApiError(resp.status, `Ahrefs API error: ${msg}`, { path, params });
  }
  return body;
}

// ---------------------------------------------------------------------------
// Date helpers (all in UTC, YYYY-MM-DD).
// ---------------------------------------------------------------------------
export function today() {
  return new Date().toISOString().slice(0, 10);
}

export function daysAgo(n) {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() - n);
  return d.toISOString().slice(0, 10);
}

export function monthsAgo(n) {
  const d = new Date();
  d.setUTCMonth(d.getUTCMonth() - n);
  return d.toISOString().slice(0, 10);
}

// ---------------------------------------------------------------------------
// Filter builders for the Ahrefs `where` grammar.
// ---------------------------------------------------------------------------
export function whereKeywordIn(keywords) {
  return { or: keywords.map((k) => ({ field: "keyword", is: ["eq", k] })) };
}

// ---------------------------------------------------------------------------
// Response helpers.
// ---------------------------------------------------------------------------

// Wrap a handler so every endpoint shares error handling + edge caching.
// `ttl` = seconds the Vercel CDN may serve the cached response. The UI can
// append ?fresh=1 to bypass the cache for that request.
export function withHandler(ttl, fn) {
  return async (req, res) => {
    try {
      const fresh = req.query?.fresh === "1";
      const data = await fn(req, res);
      if (fresh || !ttl) {
        res.setHeader("Cache-Control", "no-store");
      } else {
        res.setHeader(
          "Cache-Control",
          `public, s-maxage=${ttl}, stale-while-revalidate=${Math.round(ttl / 2)}`
        );
      }
      res.status(200).json(data);
    } catch (err) {
      const status = err instanceof ApiError ? err.status : 500;
      res.setHeader("Cache-Control", "no-store");
      res.status(status).json({
        error: err.message || "Unknown error",
        detail: err.detail || null,
      });
    }
  };
}

// Run several async tasks but never let one failure sink the whole panel —
// returns { value } or { error } per task.
export async function settle(tasks) {
  const results = await Promise.allSettled(tasks);
  return results.map((r) =>
    r.status === "fulfilled" ? { value: r.value } : { error: r.reason?.message || String(r.reason) }
  );
}
