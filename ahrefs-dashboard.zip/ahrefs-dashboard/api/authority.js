import { ahrefsGet, withHandler, monthsAgo, today, settle } from "./_ahrefs.js";
import { config } from "./_config.js";

async function drSeries(target) {
  const body = await ahrefsGet("site-explorer/domain-rating-history", {
    target,
    date_from: monthsAgo(config.historyMonths),
    date_to: today(),
    history_grouping: "monthly",
  });
  return (body.domain_ratings || []).map((d) => ({ date: d.date, value: d.domain_rating }));
}

async function refdomainsSeries(target) {
  const body = await ahrefsGet("site-explorer/refdomains-history", {
    target,
    mode: "subdomains",
    date_from: monthsAgo(config.historyMonths),
    date_to: today(),
    history_grouping: "monthly",
  });
  return (body.refdomains || []).map((d) => ({ date: d.date, value: d.refdomains }));
}

export default withHandler(config.cacheTtl.authority, async () => {
  const targets = [config.mainDomain, config.competitor];
  const dr = await settle(targets.map(drSeries));
  const rd = await settle(targets.map(refdomainsSeries));

  return {
    domainRating: targets.map((target, i) => ({
      target,
      isMain: i === 0,
      data: dr[i].value || [],
      error: dr[i].error || null,
    })),
    refdomains: targets.map((target, i) => ({
      target,
      isMain: i === 0,
      data: rd[i].value || [],
      error: rd[i].error || null,
    })),
  };
});
