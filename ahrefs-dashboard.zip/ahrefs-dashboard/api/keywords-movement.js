import { ahrefsGet, withHandler, today, daysAgo } from "./_ahrefs.js";
import { config } from "./_config.js";

// New / lost / declined organic keywords for the whole domain over the window.
// Uses date vs date_compared so Ahrefs computes the diff natively — no local
// history storage needed.
export default withHandler(config.cacheTtl.keywordMovement, async () => {
  const date = today();
  const dateCompared = daysAgo(config.backlinksWindowDays);

  const body = await ahrefsGet("site-explorer/organic-keywords", {
    target: config.mainDomain,
    mode: "subdomains",
    date,
    date_compared: dateCompared,
    country: config.country || undefined,
    volume_mode: "monthly",
    select:
      "keyword,status,best_position,best_position_prev,best_position_diff,volume,sum_traffic,sum_traffic_prev,best_position_url",
    order_by: "volume:desc",
    limit: config.limits.keywordMovement,
  });

  const rows = (body.keywords || []).map((k) => ({
    keyword: k.keyword,
    status: k.status, // left = new, right = lost, both = unchanged set
    position: k.best_position ?? null,
    position_prev: k.best_position_prev ?? null,
    position_diff: k.best_position_diff ?? null,
    volume: k.volume ?? null,
    traffic: k.sum_traffic ?? null,
    traffic_prev: k.sum_traffic_prev ?? null,
    url: k.best_position_url ?? null,
  }));

  const isWorse = (r) =>
    r.position != null && r.position_prev != null && r.position > r.position_prev;
  const isBetter = (r) =>
    r.position != null && r.position_prev != null && r.position < r.position_prev;

  const newKw = rows
    .filter((r) => r.status === "left")
    .sort((a, b) => (b.volume ?? 0) - (a.volume ?? 0));
  const lostKw = rows
    .filter((r) => r.status === "right")
    .sort((a, b) => (b.volume ?? 0) - (a.volume ?? 0));
  const dropped = rows
    .filter((r) => r.status === "both" && isWorse(r))
    .sort((a, b) => (b.position - b.position_prev) - (a.position - a.position_prev));
  const improved = rows
    .filter((r) => r.status === "both" && isBetter(r))
    .sort((a, b) => (a.position - a.position_prev) - (b.position - b.position_prev));

  return {
    window: { from: dateCompared, to: date },
    counts: {
      new: newKw.length,
      lost: lostKw.length,
      dropped: dropped.length,
      improved: improved.length,
    },
    new: newKw,
    lost: lostKw,
    dropped,
    improved,
  };
});
