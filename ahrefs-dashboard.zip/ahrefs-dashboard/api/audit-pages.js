import { ahrefsGet, withHandler, ApiError } from "./_ahrefs.js";
import { config } from "./_config.js";

// GET /api/audit-pages?issue_id=<id>
// Returns the list of URLs affected by one Site Audit issue.
export default withHandler(config.cacheTtl.auditPages, async (req) => {
  const issueId = req.query?.issue_id;
  if (!issueId) throw new ApiError(400, "Missing issue_id query parameter.");

  const body = await ahrefsGet("site-audit/page-explorer", {
    project_id: config.siteAuditProjectId,
    issue_id: issueId,
    select: "url,title,http_code,depth",
    order_by: "http_code:desc",
    limit: config.limits.auditPages,
  });

  const pages = (body.pages || []).map((p) => ({
    url: p.url,
    title: p.title,
    http_code: p.http_code,
    depth: p.depth,
  }));

  return { issue_id: issueId, count: pages.length, pages };
});
